from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, to_date

# Snowflake connection options
sfOptions = {
    "sfURL": "your_account.snowflakecomputing.com",
    "sfUser": "your_username",
    "sfPassword": "your_password",
    "sfDatabase": "your_database",
    "sfSchema": "public",
    "sfWarehouse": "your_warehouse",
    "sfRole": "your_role"
}

# Initialize Spark session with Snowflake connector
spark = SparkSession.builder \\
    .appName("PySpark to Snowflake") \\
    .config("spark.jars.packages", "net.snowflake:snowflake-jdbc:3.13.30,net.snowflake:spark-snowflake_2.12:2.9.0-spark_3.1") \\
    .getOrCreate()

# Read the CSV file
df = spark.read.option("header", True).csv("customer_data.csv")

# Basic cleaning: Fill nulls and parse dates
df_cleaned = df.fillna({"first_name": "Unknown", "signup_date": "2023-01-01"}) \\
    .withColumn("signup_date", to_date(col("signup_date")))

# Write to Snowflake
df_cleaned.write \\
    .format("snowflake") \\
    .options(**sfOptions) \\
    .option("dbtable", "CUSTOMER_DATA") \\
    .mode("overwrite") \\
    .save()

spark.stop()
